﻿using Microsoft.AspNetCore.Mvc;
using SimpleToDoApp.Models;
using SimpleToDoApp.Services;


namespace ToDoListApp.Controllers
{
    public class ToDoController : Controller
    {
        private readonly ToDoService _toDoService;

        public ToDoController(ToDoService toDoService)
        {
            _toDoService = toDoService;
        }

        public IActionResult Index()
        {
            var tasks = _toDoService.GetAllTasks();
            return View(tasks);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(ToDoItem task)
        {
            
            if (ModelState.IsValid)
            {
                _toDoService.AddTask(task);
                var tasks = _toDoService.GetAllTasks();
                Console.WriteLine($"No. of Mission:  {tasks.Count}");
                return RedirectToAction("Index");
            }
            return View(task);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var task = _toDoService.GetTaskById(id);
            if (task == null) return NotFound();
            return View(task);
        }

        [HttpPost]
        public IActionResult Edit(ToDoItem task)
        {
            if (ModelState.IsValid)
            {
                _toDoService.UpdateTask(task);
                return RedirectToAction("Index");
            }
            return View(task);
        }

        [HttpPost]
        public IActionResult Complete(int id)
        {
            _toDoService.MarkAsCompleted(id);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            _toDoService.DeleteTask(id);
            return RedirectToAction("Index");
        }
    }
}