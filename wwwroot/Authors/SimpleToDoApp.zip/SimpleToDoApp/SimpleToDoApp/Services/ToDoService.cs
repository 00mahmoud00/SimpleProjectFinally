﻿using SimpleToDoApp.Models;

namespace SimpleToDoApp.Services
{
    public class ToDoService
    {
        private readonly List<ToDoItem> _tasks = new List<ToDoItem>();
        private int _nextId = 1;

        public void AddTask(ToDoItem task)
        {
            task.Id = _nextId++;
            _tasks.Add(task);
        }

        public List<ToDoItem> GetAllTasks()
        {
            return _tasks;
        }

        public ToDoItem GetTaskById(int id)
        {
            return _tasks.FirstOrDefault(t => t.Id == id);
        }

        public void UpdateTask(ToDoItem task)
        {
            var existingTask = GetTaskById(task.Id);
            if (existingTask != null)
            {
                existingTask.Title = task.Title;
                existingTask.IsCompleted = task.IsCompleted;
            }
        }

        public void MarkAsCompleted(int id)
        {
            var task = GetTaskById(id);
            if (task != null)
            {
                task.IsCompleted = true;
            }
        }

        public void DeleteTask(int id)
        {
            var task = GetTaskById(id);
            if (task != null)
            {
                _tasks.Remove(task);
            }
        }
    }
}